package com.whj.axiosserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AxiosserverApplicationTests {

    @Test
    void contextLoads() {
    }

}
