package com.whj.axiosserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AxiosserverApplication {

    public static void main(String[] args) {
        SpringApplication.run(AxiosserverApplication.class, args);
    }

}
