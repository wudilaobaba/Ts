import {
  AxiosPromise,
  RequestData,
  Method,
  AxiosResponse,
  ResolvedFn,
  RejectedFn
} from "../types/index"
import {axios} from "../axios"
import InterceptorManager from "../intecepter/InterceptorManager";
import {rejects} from "assert";

export default class WhjAxios{
  private interceptors:Interceptors;
  constructor() {
    this.interceptors = {
      // 可以实现链式调用:
      // let num:number = new WhjAxios().getInterceptors().request.use(函数1,函数2); //添加请求拦截器
      // let num:number = new WhjAxios().getInterceptors().response.use(函数1,函数2); //添加响应拦截器
      request:new InterceptorManager<RequestData>(),
      response:new InterceptorManager<AxiosResponse>()
    }
  }
  public getInterceptors():Interceptors{
    return this.interceptors;
  }


  // 原始ajax
  public request(config:RequestData):Promise<RequestData>{
    // 初始化链式调用
    const chain:Array<PromiseChain<any>> = [{
      resolved:axios,
      rejected:undefined
    }];
    // 添加请求拦截器，
    this.interceptors.request.forEach(interceptor => {
      // 后添加的先执行
      chain.unshift(interceptor);
    });
    // 添加响应拦截器
    this.interceptors.response.forEach(interceptor => {
      // 先添加的先执行
      chain.push(interceptor);
    });
    let promise = Promise.resolve(config);
    while (chain.length){
      const {resolved,rejected} = chain.shift()!;
      promise = promise.then(resolved,rejected);
    }
    return promise;
  }


  // 以下是扩展方法
  // 不传body体的场景
  public get(url:string,config?:RequestData):Promise<RequestData>{
    return this.requestMethodWithoutData("get",url,config);
  }
  public delete(url:string,config?:RequestData):Promise<RequestData>{
    return this.requestMethodWithoutData("delete",url,config);
  }
  public head(url:string,config?:RequestData):Promise<RequestData>{
    return this.requestMethodWithoutData("head",url,config);
  }
  public options(url:string,config?:RequestData):Promise<RequestData>{
    return this.requestMethodWithoutData("options",url,config);
  }

  // 传body体的场景
  public post(url:string,data?:any,config?:RequestData):Promise<RequestData>{
    return this.requestMethodWithData("post",url,data,config);
  }
  public put(url:string,data?:any,config?:RequestData):Promise<RequestData>{
    return this.requestMethodWithData("put",url,data,config);
  }
  public patch(url:string,data?:any,config?:RequestData):Promise<RequestData>{
    return this.requestMethodWithData("patch",url,data,config);
  }

  private requestMethodWithoutData(method:Method,url:string,config?:RequestData):Promise<RequestData>{
    return this.request(Object.assign(config||{},{
      method,
      url
    }));
  }

  private requestMethodWithData(method:Method,url:string,data?:any,config?:RequestData):Promise<RequestData>{
    return this.request(Object.assign(config||{},{
      method,
      url,
      data
    }));
  }
}

interface Interceptors {
  request:InterceptorManager<RequestData>,
  response:InterceptorManager<AxiosResponse>
}

interface PromiseChain<T> {
  resolved:ResolvedFn<T> | ((config:RequestData)=>AxiosResponse),
  rejected?:RejectedFn
}
