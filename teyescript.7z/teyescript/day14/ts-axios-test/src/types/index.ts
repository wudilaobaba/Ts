export declare type Method = 'get'|'GET'|'delete'|'DELETE'|'head'|'HEAD'|'options'|'OPTIONS'|'post'|'POST'|'put'|'PUT'|'patch'|'PATCH';
export interface RequestData {
  method?:Method;
  url?:string;
  data?:any;
  params?:any;
  headers?:any;
  responseType?:XMLHttpRequestResponseType;/*响应的数据类型 可传json,text,blob等字符串 */
  timeout?:number; // 该时间内，如果后端没有返回数据，则前端会做相应的处理 不传或传0都是不超时  单位为毫秒
}

export interface AxiosResponse {
  axiosConfig:RequestData,
  xmlHttpRequest:any
  responseHeaders:any,/*响应头*/
  responseData:any,
  status:number,
  statusText:string,
}

export interface AxiosPromise extends Promise<AxiosResponse>{

}

// 拦截器
export interface AxiosInterceptorMannger<T> {
  use(resolved:ResolvedFn<T>,rejected?:RejectedFn):number; // 创建拦截器的方法
  eject(id:number):void;// 根据创建出来的拦截器的number来删除拦截器
}

export interface ResolvedFn<T> {
  (val:T):T | Promise<T>
}
export interface RejectedFn {
  (error:any):any
}


