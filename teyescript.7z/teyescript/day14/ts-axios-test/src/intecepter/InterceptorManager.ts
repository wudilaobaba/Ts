import {ResolvedFn, RejectedFn, AxiosInterceptorMannger} from "../types";

export default class InterceptorManager<T> implements AxiosInterceptorMannger<T>{
  private interceptors:Array<Interceptor<T> | null>;
  constructor() {
    this.interceptors = [];
  }

  // 删除一个拦截器
  public eject(id: number): void {
    if(this.interceptors[id]){
      this.interceptors[id] = null;
    }
  }

  // 添加一个拦截器
  public use(resolved: ResolvedFn<T>, rejected?: RejectedFn): number {
    this.interceptors.push({
      resolved,
      rejected
    });
    return this.interceptors.length - 1;
  }

  // 遍历拦截器
  public forEach(fn:(interceptor:Interceptor<T>)=>void):void{
    this.interceptors.forEach(interceptor=>{
      if(interceptor !== null){
        fn(interceptor);
      }
    })
  }

}

// 定义拦截器类型
interface Interceptor<T> {
  resolved:ResolvedFn<T>;
  rejected?:RejectedFn;
}
