import {isPlainObject} from "../src/helpers/util";
let a = [1,2,3];
console.log(isPlainObject(a));
