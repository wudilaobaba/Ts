"use strict";
exports.__esModule = true;
var util_1 = require("../src/helpers/util");
var a = [1, 2, 3];
console.log(util_1.isPlainObject(a));
