function greeter(person){
  return 'Hello ' + person;
}
let user = 'Yee';
console.log(greeter(user))
