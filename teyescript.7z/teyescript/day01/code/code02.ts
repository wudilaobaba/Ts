function greeter(person: string){
  return 'Hello ' + person;
}
let user = 'Yee';
console.log(greeter(user))
