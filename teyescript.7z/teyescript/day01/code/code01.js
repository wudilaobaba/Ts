function greeter(person) {
    return 'Hello ' + person;
}
var user = 'Yee';
console.log(greeter(user));
