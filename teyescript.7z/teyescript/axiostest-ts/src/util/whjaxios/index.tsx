import {axios} from "./whj-asioss";
export * from "./types/index";
export default axios;
