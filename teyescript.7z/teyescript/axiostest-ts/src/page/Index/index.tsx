import React, {
  PureComponent,
  Fragment
} from 'react'
import axios ,{AxiosError} from "whjaxios"
class Index extends PureComponent{
  constructor(props:any, context:any) {
    super(props, context);
  }
  render() {
    return (
        <Fragment>
          首页123456789
        </Fragment>
    )
  }
  componentDidMount(){
    axios({
      url:"http://localhost:8599/v1/banner/all",
      method:"post",
      params:{
        name:"x",
        // hobbies:[11,22,33]
      },
      // timeout:10,
      // responseType:"json",
      data:[1,2,3]
    }).then((x:any)=>{
      console.log("---->",x);
    }).catch((e:AxiosError)=>{
      //message, config, code, request, response
      console.log("message",e.message);
      console.log("config",e.config);
      console.log("code",e.code);
      console.log("request",e.request);
      console.log("response",e.response);
    })
  }
}
export default Index;
