var isDone = true;
var a = 20; //十进制
var b = 0x14; //十六进制
var c = 20; //二进制
var d = 20; //八进制
var xx = 'bob';
xx = "Smith";
var name1 = 'Yee';
var age = 30;
var s = "\n  Hello," + name1 + "\n  " + age + "\n";
console.log(s);
var list1 = [1, 2, 3];
var list2 = [1, 2, 4];
//元组
var x = ['h', 1]; //定义的是两个元素的数组，每个元素的类型清晰可见
console.log(x[0]);
