"use strict";
exports.__esModule = true;
var TestClass = /** @class */ (function () {
    function TestClass() {
    }
    TestClass.prototype.sayHi = function () {
        return "here we go";
    };
    return TestClass;
}());
exports["default"] = TestClass;
