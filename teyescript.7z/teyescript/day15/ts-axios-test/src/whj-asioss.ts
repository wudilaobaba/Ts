import WhjAxios from "./core/WhjAxios"
let axios:WhjAxios = new WhjAxios();
export default axios;
