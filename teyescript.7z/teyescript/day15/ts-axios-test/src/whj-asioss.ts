import WhjAxios from "./core/WhjAxios"
import {RequestData} from "./types";

/**
 * 将一个配置文件传递到createAxios方法中
 * @param defaults
 */
export default function createAxios(defaults:RequestData):WhjAxios{
  let axios:WhjAxios = new WhjAxios(defaults);
  return axios;
}

