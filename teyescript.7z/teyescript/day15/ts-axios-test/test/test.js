"use strict";
exports.__esModule = true;
var TestClass_1 = require("../src/test/TestClass");
exports["default"] = TestClass_1["default"];
console.log(new TestClass_1["default"]().sayHi());
