import React, {
  PureComponent,
  Fragment
} from 'react'
import xhr from "./XhrTest";
import axiox from "whj-axios"
class TestDom extends PureComponent {
  constructor(props, context) {
    super(props, context);
  }
  render() {
    return (
        <Fragment>
          首页123
        </Fragment>
    )
  }

  componentDidMount() {
    let config = {
      url:"http://localhost:8599/v1/banner/all",
      method:"get",
      data:null,
      params:{
        // string:"Mike",
        // list:[
        //     "sad", {sex:"男"}, new Date()
        // ],
        // names:["Mike","TOM","Kite","John"],
        // date:new Date()
        calendar:new Date(),
      }
    };
    axiox(config);
  }
}
export default TestDom
