import React from 'react';
import TestDom from "./test/TestDom";
function App() {
  return (
    <div>
      <TestDom/>
    </div>
  );
}

export default App;
