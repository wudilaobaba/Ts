export const BASEURL = 'http://localhost:8599/v1';
export const GETHEADERS = {}
export const POSTHEADERS = {}

//以下待选适用于post请求的请求头，get请求头部不传'Content-type'
//"Content-type": "application/json;charset=utf-8"
//"Content-type": "application/x-www-form-urlencoded;charset=utf-8"
//"Content-type": "text/plain;charset=utf-8"
//"Content-type": "text/html;charset=utf-8"
//"Content-type": "application/javascript;charset=utf-8"
//"Content-type": "application/xml;charset=utf-8"
//"Content-type": "text/xml;charset=utf-8"
