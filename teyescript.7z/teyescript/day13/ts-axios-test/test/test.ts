import TestClass from "../src/test/TestClass";
export default TestClass;





