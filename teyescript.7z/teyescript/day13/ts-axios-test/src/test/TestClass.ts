export interface TestClass {
  get():void;
  post():void;
}

export class Whj{
  public get(): void {
    console.log("GET");
  };
  public post(): void {
    console.log("POST");
  };
  private static sayHi():void{
    console.log("sayHi");
  }
}
