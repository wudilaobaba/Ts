import {Axios} from "./types"
import WhjAxios from "./core/WhjAxios"
let axios:Axios = new WhjAxios();
export default axios;
